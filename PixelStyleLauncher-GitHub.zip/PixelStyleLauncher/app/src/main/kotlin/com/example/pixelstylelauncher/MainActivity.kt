package com.example.pixelstylelauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private var drawerOpen = false
    private var dark = false
    private var wallpaperColor = Color.rgb(94, 143, 190)
    private var gridColumns = 4
    private var iconSize = 56
    private var labels = true
    private var searchEnabled = true
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", false)
        wallpaperColor = prefs.getInt("wallpaper", Color.rgb(94,143,190))
        gridColumns = prefs.getInt("columns", 4)
        iconSize = prefs.getInt("icon_size", 56)
        labels = prefs.getBoolean("labels", true)
        searchEnabled = prefs.getBoolean("search", true)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun bg(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun text(value: String, size: Float, color: Int = fg(), bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
    private fun fg() = if (dark) Color.WHITE else Color.rgb(25, 35, 48)
    private fun panel() = if (dark) Color.rgb(31, 40, 53) else Color.rgb(255,255,255)
    private fun pageBg() = if (dark) Color.rgb(17, 24, 35) else Color.rgb(235, 242, 249)
    private fun pad(v: View, n: Int = 12) { v.setPadding(dp(n),dp(n),dp(n),dp(n)) }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun column(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun basePage(): LinearLayout {
        root = column().apply {
            val end = if (dark) Color.rgb(24, 34, 49) else Color.rgb(127, 171, 207)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(wallpaperColor, end))
            setPadding(dp(12),dp(12),dp(12),dp(8))
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        return root
    }

    private fun showHome() {
        drawerOpen = false
        basePage()
        val scroll = ScrollView(this)
        val home = column()
        scroll.addView(home)
        content.addView(scroll)
        val date = text("10:24     ●  ▴  ▰  85%", 12f, if (dark) Color.WHITE else Color.WHITE)
        date.setPadding(dp(4),dp(2),dp(4),dp(12))
        home.addView(date)
        val glance = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = bg(panel(),24); pad(this,18)
        }
        val weather = column()
        weather.addView(text("☀  Kayseri", 13f, fg(), true))
        weather.addView(text("18°", 31f, fg(), true))
        weather.addView(text("Parçalı bulutlu", 12f))
        glance.addView(weather, LinearLayout.LayoutParams(0,dp(100),1f))
        val events = column().apply { setPadding(dp(12),0,0,0) }
        events.addView(text("Bugün",13f,fg(),true))
        events.addView(text("2 etkinlik",12f))
        events.addView(text("10:00  Toplantı",11f))
        events.addView(text("15:00  Randevu",11f))
        glance.addView(events, LinearLayout.LayoutParams(0,-2,1f))
        home.addView(glance, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(28) })

        val favorites = listOf("Gmail","Haritalar","YouTube","Fotoğraflar","Play Store","Drive","Ayarlar","Dosyalar")
        home.addView(appGrid(favorites, 4, true), LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(20) })
        val spacer = View(this)
        home.addView(spacer, LinearLayout.LayoutParams(1,dp(50)))
        if (searchEnabled) {
            val search = row().apply { background=bg(panel(),28); pad(this,12) }
            search.addView(text("🌐  Google araması",15f), LinearLayout.LayoutParams(0,dp(34),1f))
            search.addView(text("🎙   ◉",18f))
            home.addView(search)
        }
        val dock = row().apply { gravity=Gravity.CENTER; setPadding(0,dp(8),0,dp(8)) }
        listOf("☎","●","🌐","📷").forEachIndexed { i, s ->
            val item = text(s,25f,Color.WHITE,true).apply {
                gravity=Gravity.CENTER; background=bg(listOf(0xff2586e8.toInt(),0xff1689d5.toInt(),0xffea5147.toInt(),0xff3c80db.toInt())[i],50)
            }
            dock.addView(item, LinearLayout.LayoutParams(0,dp(48),1f).apply { marginStart=dp(8); marginEnd=dp(8) })
            item.setOnClickListener { if(i==2) openApp("com.android.chrome") else if(i==3) openApp("com.android.camera2") else showDrawer() }
        }
        root.addView(dock,0,LinearLayout.LayoutParams(-1,-2))
        val nav = text("━━━━━━━━━━━━━━━━",12f,if(dark) Color.LTGRAY else Color.DKGRAY).apply { gravity=Gravity.CENTER; setPadding(0,dp(4),0,0) }
        root.addView(nav)
        content.setOnLongClickListener { showHomeMenu(); true }
        content.setOnClickListener { }
    }

    private fun appGrid(names: List<String>, cols: Int, launch: Boolean): GridLayout {
        val grid = GridLayout(this).apply { columnCount=cols; alignmentMode=GridLayout.ALIGN_BOUNDS; useDefaultMargins=false }
        names.forEach { name ->
            val item = column().apply { gravity=Gravity.CENTER; setPadding(dp(3),dp(8),dp(3),dp(8)) }
            val icon = text(iconFor(name), 24f, Color.WHITE, true).apply {
                gravity=Gravity.CENTER; background=bg(colorFor(name),50)
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(iconSize),dp(iconSize)))
            if (labels) item.addView(text(name,10.5f,fg()).apply { gravity=Gravity.CENTER; maxLines=1 })
            item.setOnClickListener { if (launch) openAppForName(name) else openAppForName(name) }
            item.setOnLongClickListener { appMenu(name); true }
            grid.addView(item, GridLayout.LayoutParams().apply {
                width=0; height=ViewGroup.LayoutParams.WRAP_CONTENT; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                setMargins(dp(3),dp(2),dp(3),dp(2))
            })
        }
        return grid
    }

    private fun showDrawer(filter: String = "") {
        drawerOpen = true
        basePage()
        val header = row()
        header.addView(text("Uygulamalar",22f,fg(),true), LinearLayout.LayoutParams(0,-2,1f))
        val close = text("✕",20f).apply { gravity=Gravity.CENTER; setOnClickListener { showHome() } }
        header.addView(close,LinearLayout.LayoutParams(dp(40),dp(44)))
        content.addView(header)
        val wrap = column()
        if (searchEnabled) {
            val search = EditText(this).apply {
                hint="Uygulamaları ara"; textSize=15f; singleLine=true
                setTextColor(fg()); setHintTextColor(if(dark) 0xffaab4c2.toInt() else 0xff687789.toInt())
                background=bg(panel(),28); setPadding(dp(16),dp(8),dp(16),dp(8))
            }
            wrap.addView(search,LinearLayout.LayoutParams(-1,dp(50)).apply { bottomMargin=dp(10) })
            search.setText(filter)
            search.addTextChangedListener(object: TextWatcher {
                override fun beforeTextChanged(s: CharSequence?,start:Int,count:Int,after:Int) {}
                override fun onTextChanged(s: CharSequence?,start:Int,before:Int,count:Int) { renderApps(wrap,s?.toString().orEmpty()) }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        val list = ScrollView(this)
        val appArea = column()
        list.addView(appArea)
        wrap.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        content.addView(wrap,FrameLayout.LayoutParams(-1,-1).apply { topMargin=dp(54) })
        renderApps(appArea,filter)
        root.setOnLongClickListener { showHomeMenu(); true }
    }

    private fun renderApps(target: LinearLayout, filter: String) {
        target.removeAllViews()
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName)!=null && it.packageName!=packageName }
            .map { it to packageManager.getApplicationLabel(it).toString() }
            .filter { it.second.contains(filter,true) }
            .sortedBy { it.second.lowercase() }
        val grid = GridLayout(this).apply { columnCount=gridColumns }
        apps.forEach { (info,name) ->
            val item = column().apply { gravity=Gravity.CENTER; setPadding(dp(4),dp(9),dp(4),dp(9)) }
            val icon = ImageView(this).apply {
                setImageDrawable(packageManager.getApplicationIcon(info)); scaleType=ImageView.ScaleType.FIT_CENTER
            }
            item.addView(icon,LinearLayout.LayoutParams(dp(iconSize),dp(iconSize)))
            if(labels) item.addView(text(name,10.5f,fg()).apply { gravity=Gravity.CENTER; maxLines=2; textAlignment=View.TEXT_ALIGNMENT_CENTER })
            item.setOnClickListener { packageManager.getLaunchIntentForPackage(info.packageName)?.let { startActivity(it) } }
            item.setOnLongClickListener { appMenu(name,info.packageName); true }
            grid.addView(item,GridLayout.LayoutParams().apply {
                width=0; height=ViewGroup.LayoutParams.WRAP_CONTENT; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                setMargins(dp(2),dp(2),dp(2),dp(2))
            })
        }
        target.addView(grid)
        if(apps.isEmpty()) target.addView(text("Uygulama bulunamadı",15f).apply { gravity=Gravity.CENTER; setPadding(0,dp(30),0,0) })
    }

    private fun showHomeMenu() {
        AlertDialog.Builder(this).setTitle("Ana ekranı özelleştir")
            .setItems(arrayOf("Duvar kâğıdı ve stil","Widget ekle","Uygulamalar listesi","Ana ekran ayarları")) { _, which ->
                when(which) { 0->showWallpaper(); 1->showWidgets(); 2->showDrawer(); 3->showSettings() }
            }.show()
    }
    private fun appMenu(name:String, pkg:String?=null) {
        val options = arrayOf("Aç","Uygulama bilgisi","Kaldır")
        AlertDialog.Builder(this).setTitle(name).setItems(options) { _, which ->
            when(which) {
                0 -> if(pkg!=null) packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } else openAppForName(name)
                1 -> if(pkg!=null) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:$pkg")))
                2 -> if(pkg!=null) startActivity(Intent(Intent.ACTION_DELETE,android.net.Uri.parse("package:$pkg")))
            }
        }.show()
    }
    private fun showWallpaper() {
        val colors = arrayOf("Okyanus mavisi","Gece modu","Lavanta","Yeşil","Gül kurusu")
        val values = intArrayOf(0xff5e8fbe.toInt(),0xff202b3c.toInt(),0xff9187d9.toInt(),0xff7c9e83.toInt(),0xffd99191.toInt())
        AlertDialog.Builder(this).setTitle("Wallpaper & style").setItems(colors) { _, which ->
            wallpaperColor=values[which]; dark=which==1
            prefs.edit().putInt("wallpaper",wallpaperColor).putBoolean("dark",dark).apply()
            showHome()
        }.setNegativeButton("Sistem duvar kâğıdı") { _,_-> try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (_:Exception) {} }.show()
    }
    private fun showWidgets() {
        val widgetOptions = arrayOf("Google arama çubuğu","At a Glance / hava durumu","Takvim","Fotoğraflar","Saat")
        AlertDialog.Builder(this).setTitle("Widget ekle")
            .setItems(widgetOptions) { _, which ->
                AlertDialog.Builder(this).setMessage("${widgetOptions[which]} widget'ı, Android'in widget seçicisinden eklenir. Ana ekranı uzun basıp tekrar deneyin veya aşağıdaki sistem ekranını açın.")
                    .setPositiveButton("Widget ekranını aç") { _,_-> try { startActivity(Intent("android.appwidget.action.APPWIDGET_PICK")) } catch (_:Exception) { showSettings() } }
                    .setNegativeButton("Tamam",null).show()
            }.show()
    }
    private fun showSettings() {
        val options = arrayOf("Tema: ${if(dark) "Koyu" else "Açık"}","Uygulama ızgarası: ${gridColumns} sütun","Simge boyutu: $iconSize","Uygulama adlarını göster: ${if(labels) "Açık" else "Kapalı"}","Arama çubuğu: ${if(searchEnabled) "Açık" else "Kapalı"}","Varsayılan ana ekran uygulaması")
        AlertDialog.Builder(this).setTitle("Ana ekran ayarları").setItems(options) { _,which ->
            when(which) {
                0 -> { dark=!dark; prefs.edit().putBoolean("dark",dark).apply(); showHome() }
                1 -> AlertDialog.Builder(this).setTitle("Izgara sütun sayısı").setSingleChoiceItems(arrayOf("3 sütun","4 sütun","5 sütun","6 sütun"),gridColumns-3) { d,idx -> gridColumns=idx+3; prefs.edit().putInt("columns",gridColumns).apply(); d.dismiss(); if(drawerOpen) showDrawer() else showHome() }.show()
                2 -> AlertDialog.Builder(this).setTitle("Simge boyutu").setSingleChoiceItems(arrayOf("Küçük (44 dp)","Orta (56 dp)","Büyük (68 dp)"),(iconSize/12)-3) { d,idx -> iconSize=44+idx*12; prefs.edit().putInt("icon_size",iconSize).apply(); d.dismiss(); if(drawerOpen) showDrawer() else showHome() }.show()
                3 -> { labels=!labels; prefs.edit().putBoolean("labels",labels).apply(); if(drawerOpen) showDrawer() else showHome() }
                4 -> { searchEnabled=!searchEnabled; prefs.edit().putBoolean("search",searchEnabled).apply(); if(drawerOpen) showDrawer() else showHome() }
                5 -> try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (_:Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }.show()
    }
    private fun openAppForName(name:String) {
        val pkg = when(name) {
            "Ayarlar"->"com.android.settings"; "Chrome"->"com.android.chrome"; "YouTube"->"com.google.android.youtube"
            "Play Store"->"com.android.vending"; "Gmail"->"com.google.android.gm"; "Haritalar"->"com.google.android.apps.maps"
            "Fotoğraflar"->"com.google.android.apps.photos"; "Drive"->"com.google.android.apps.docs"; else->null
        }
        if(pkg!=null) openApp(pkg) else showDrawer()
    }
    private fun openApp(pkg:String) {
        val intent=packageManager.getLaunchIntentForPackage(pkg)
        if(intent!=null) startActivity(intent) else Toast.makeText(this,"Bu uygulama cihazda bulunamadı",Toast.LENGTH_SHORT).show()
    }
    private fun iconFor(name:String)=when(name) {
        "Gmail"->"M"; "Haritalar"->"♦"; "YouTube"->"▶"; "Fotoğraflar"->"✿"; "Play Store"->"▷"; "Drive"->"▲"; "Ayarlar"->"⚙"; "Dosyalar"->"▰"; else->name.take(1)
    }
    private fun colorFor(name:String)=when(name) {
        "Gmail"->0xffdf5147.toInt(); "Haritalar"->0xff24a879.toInt(); "YouTube"->0xffe53935.toInt()
        "Fotoğraflar"->0xff4285f4.toInt(); "Play Store"->0xff32a8e0.toInt(); "Drive"->0xff35a853.toInt()
        "Ayarlar"->0xff3579c6.toInt(); "Dosyalar"->0xff4389d7.toInt(); else->0xff477fb4.toInt()
    }
}
