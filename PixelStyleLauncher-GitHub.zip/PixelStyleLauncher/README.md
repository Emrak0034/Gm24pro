# Pixel Style Launcher (Android)

Android launcher başlangıç projesi: Material/Pixel tarzı ana ekran, uygulama çekmecesi, arama, uzun basma menüsü, renk/tema seçimi ve temel kişiselleştirme ayarları içerir. General Mobile GM 24 Pro / Android 14 hedeflenerek hazırlanmıştır; cihazdaki uygulamalar sistem paket yöneticisinden dinamik listelenir.

## GitHub üzerinden APK derleme (ZIP ile)

1. Bu ZIP'i bilgisayarınıza indirin ve açın.
2. GitHub'da yeni, boş bir repository oluşturun.
3. ZIP içindeki **dosya ve klasörleri** repository köküne yükleyin (ZIP dosyasının kendisini repo içine atmak yeterli değildir). GitHub web arayüzünde `Add file > Upload files` ile çoklu dosyaları/klasörleri yükleyebilir veya bilgisayarda `git` ile push edebilirsiniz.
4. `app/build.gradle`, `settings.gradle`, `build.gradle`, `gradle.properties`, `app/src/...` ve `.github/workflows/android.yml` kök düzenini koruyun.
5. `Actions` sekmesini açın. İlk push'ta workflow otomatik çalışabilir; değilse **Build Android APK > Run workflow** seçin.
6. Tamamlanınca workflow çalışmasının altındaki **Artifacts** bölümünden `PixelStyleLauncher-debug-apk` dosyasını indirin.
7. İnen artifact ZIP'ini açın; içindeki `app-debug.apk` dosyasını GM 24 Pro'ya gönderip kurun. Android izin isterse yalnızca güvendiğiniz kendi derlemeniz için izin verin.
8. Kurulumdan sonra Ana ekran/Home uygulaması sorulduğunda **Pixel Style Launcher** seçin. Sonradan Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması kısmından değiştirebilirsiniz.

## Özellikler

- Ana ekran ve dock görünümü
- Uygulama çekmecesi, gerçek kurulu uygulamaları listeleme ve arama
- Uygulama simgesine uzun basınca açma, uygulama bilgisi ve kaldırma kısayolları
- Duvar kâğıdı rengi/tema seçimi, açık-koyu tema
- 3–6 sütun uygulama ızgarası
- Simge boyutu ve etiketleri gösterme ayarı
- Arama çubuğunu açma/kapatma
- Ana ekran uzun basma menüsü

## Önemli kapsam notları

Bu ilk sürüm, gönderdiğiniz görseldeki tasarıma **yakın bir başlangıç uygulamasıdır; görselin piksel piksel birebir kopyası değildir**. Görseldeki gerçek Android widget'larının (At a Glance, hava durumu, takvim vb.) tam davranışı, sayfalar arası sürükle-bırak, ikon paketi desteği, gerçek widget host/izin akışı ve animasyonlar henüz tam bir launcher seviyesinde uygulanmamıştır. Android'in widget API'si ve OEM/Android sürümlerine göre ek entegrasyon gerekir.

## Teknik

- Kotlin + Android SDK
- Min SDK 26; target SDK 35
- Java 17
- Üçüncü taraf runtime kütüphanesi yok
- GitHub Actions, debug APK üretir

Bu, imzalı dağıtım sürümü değil debug APK üretir. Play Store veya herkese dağıtım için ayrıca release signing yapılandırılmalıdır.
